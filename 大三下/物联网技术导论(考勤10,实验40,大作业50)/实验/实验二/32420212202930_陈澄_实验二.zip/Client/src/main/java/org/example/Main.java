package org.example;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            InetAddress address = InetAddress.getByName("localhost");
            int port = 12345;

            Random random = new Random();

            while (true) {
                // 模拟温度数据
                double temperature = 20 + random.nextGaussian() * 5; // 均值为20，标准差为5

                String data = String.valueOf(temperature);
                byte[] sendData = data.getBytes();

                DatagramPacket packet = new DatagramPacket(sendData, sendData.length, address, port);
                socket.send(packet);

                System.out.println("Sent data: " + data);

                Thread.sleep(5000); // 采样频率设定为5秒
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
