package com.example.server.controller;

import com.example.server.mapper.MessageMapper;
import com.example.server.pojo.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

@RestController
public class MessageController {
    @Autowired
    MessageMapper messageMapper;

    @GetMapping("/data")
    public ArrayList<Message> getAll(){
        return messageMapper.getAll();
    }
}
