package com.example.server.mapper;

import com.example.server.pojo.Message;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.ArrayList;

@Mapper
public interface MessageMapper {
    @Insert("insert into message(date,temperature) values (#{date},#{temperature})")
    void insert(Message message);

    @Select("select * from message")
    ArrayList<Message> getAll();
}
