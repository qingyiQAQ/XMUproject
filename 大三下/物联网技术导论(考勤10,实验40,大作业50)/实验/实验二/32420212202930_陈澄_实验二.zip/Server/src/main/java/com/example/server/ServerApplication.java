package com.example.server;

import com.example.server.mapper.MessageMapper;
import com.example.server.pojo.Message;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.net.*;
import java.time.LocalDateTime;

@SpringBootApplication
public class ServerApplication {

    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(ServerApplication.class, args);
        try {

            // 创建UDP套接字并绑定到指定端口
            DatagramSocket serverSocket = new DatagramSocket(12345);

            System.out.println("服务器已启动，等待客户端连接...");

            // 创建接收数据的缓冲区
            byte[] receiveData = new byte[1024];

            while (true) {
                // 创建接收数据报
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                // 接收数据报
                serverSocket.receive(receivePacket);

                // 解析接收到的数据
                String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("收到消息：" + message);

                MessageMapper messageMapper = context.getBean(MessageMapper.class);
                Message temperature = new Message(LocalDateTime.now(),Double.parseDouble(message));
                messageMapper.insert(temperature);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOrigin("http://127.0.0.1:5500"); // 允许访问的域
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }

}
