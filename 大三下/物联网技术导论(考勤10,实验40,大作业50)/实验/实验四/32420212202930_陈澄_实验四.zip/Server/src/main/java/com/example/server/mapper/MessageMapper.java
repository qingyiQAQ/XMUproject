package com.example.server.mapper;

import com.example.server.pojo.PressureMessage;
import com.example.server.pojo.TemperatureMessage;
import com.example.server.pojo.VolumeMessage;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.ArrayList;

@Mapper
public interface MessageMapper {
    @Insert("insert into temperaturemessage(date,temperature) values (#{date},#{temperature})")
    void insertTemperature(TemperatureMessage message);

    @Insert("insert into pressuremessage(date,pressure) values (#{date},#{pressure})")
    void insertPressure(PressureMessage message);

    @Insert("insert into volumemessage(date,volume) values (#{date},#{volume})")
    void insertVolume(VolumeMessage message);

    @Select("select * from temperaturemessage")
    ArrayList<TemperatureMessage> getAllTemperature();

    @Select("select * from pressuremessage")
    ArrayList<PressureMessage> getAllPressure();

    @Select("select * from volumemessage")
    ArrayList<VolumeMessage> getAllVolume();
}
