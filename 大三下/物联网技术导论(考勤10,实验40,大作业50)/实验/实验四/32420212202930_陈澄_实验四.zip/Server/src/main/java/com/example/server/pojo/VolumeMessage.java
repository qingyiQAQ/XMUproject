package com.example.server.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class VolumeMessage {
    private LocalDateTime date;
    private double volume;
}
