package com.example.server.controller;

import com.example.server.mapper.MessageMapper;
import com.example.server.pojo.PressureMessage;
import com.example.server.pojo.TemperatureMessage;
import com.example.server.pojo.VolumeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

@RestController
public class MessageController {
    @Autowired
    MessageMapper messageMapper;

    @GetMapping("/temperature")
    public ArrayList<TemperatureMessage> getAllTemperature(){
        return messageMapper.getAllTemperature();
    }

    @GetMapping("/pressure")
    public ArrayList<PressureMessage> getAllPressure(){
        return messageMapper.getAllPressure();
    }

    @GetMapping("/volume")
    public ArrayList<VolumeMessage> getAllVolumn(){
        return messageMapper.getAllVolume();
    }
}
