package com.example.server;

import com.example.server.mapper.MessageMapper;
import com.example.server.pojo.PressureMessage;
import com.example.server.pojo.TemperatureMessage;
import com.example.server.pojo.VolumeMessage;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.net.*;
import java.time.LocalDateTime;

@SpringBootApplication
public class ServerApplication {

    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(ServerApplication.class, args);
        try {

            // 创建UDP套接字并绑定到指定端口
            DatagramSocket serverSocket = new DatagramSocket(12345);

            System.out.println("服务器已启动，等待客户端连接...");

            // 创建接收数据的缓冲区
            byte[] receiveData = new byte[1024];

            while (true) {
                // 创建接收数据报
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                // 接收数据报
                serverSocket.receive(receivePacket);

                // 解析接收到的数据
                String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("收到消息：" + message);

                MessageMapper messageMapper = context.getBean(MessageMapper.class);

                if(message.charAt(0)=='t') {
                    TemperatureMessage temperature = new TemperatureMessage(LocalDateTime.now(), Double.parseDouble(message.substring(1)));
                    messageMapper.insertTemperature(temperature);
                    if(Double.parseDouble(message.substring(1))>24.0) CustomRobotGroupMessage.send("温度超过阈值24!");
                }
                else if(message.charAt(0)=='p'){
                    PressureMessage pressure = new PressureMessage(LocalDateTime.now(), Double.parseDouble(message.substring(1)));
                    messageMapper.insertPressure(pressure);
                    if(Double.parseDouble(message.substring(1))>100020.0) CustomRobotGroupMessage.send("压力超过阈值100020!");
                }
                else if(message.charAt(0)=='v'){
                    VolumeMessage volume = new VolumeMessage(LocalDateTime.now(), Double.parseDouble(message.substring(1)));
                    messageMapper.insertVolume(volume);
                    if(Double.parseDouble(message.substring(1))>110.0) CustomRobotGroupMessage.send("体积超过阈值110!");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOriginPattern("*"); // 允许访问的域
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }

}
