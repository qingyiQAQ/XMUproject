package com.example.server.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class PressureMessage {
    private LocalDateTime date;
    private double pressure;
}
