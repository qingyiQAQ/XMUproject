package org.example;

import java.net.*;

public class UDPThroughputTest {
    static int packetSizeBytes = 1024; // 数据包大小，单位字节
    static int packetCount = 1000; // 发送数据包的数量
    static int port = 12345; // UDP端口

    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            byte[] sendData = new byte[packetSizeBytes];

            // 发送数据包
            for (int i = 0; i < packetCount; i++) {
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,
                        InetAddress.getByName("10.32.61.65"), port);
                socket.send(sendPacket);
            }

            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
