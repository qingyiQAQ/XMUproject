package org.example;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;

public class Main {

    static int packetSizeBytes = 12; // 数据包大小，单位字节
    static int packetCount = 1000; // 发送数据包的数量
    static int port = 12345; // UDP端口
    static long startTime;
    static long endTime;
    static int receivedCount = 0;

    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket(port);

            // 接收数据包
            byte[] receiveData = new byte[packetSizeBytes];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

            startTime = System.currentTimeMillis();
            while (receivedCount < packetCount) {
                try {
                    socket.receive(receivePacket);
                    receivedCount++;
                } catch (SocketTimeoutException e) {
                    System.out.println("Timeout occurred while waiting for packet.");
                }
            }
            endTime = System.currentTimeMillis();
            socket.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }

        // 计算吞吐量
        System.out.println("发送数据包数量：" + packetCount);
        System.out.println("接收数据包数量：" + receivedCount);
        double totalTimeSeconds = endTime - startTime;
        System.out.println("所需时间：" + totalTimeSeconds + "ms");
        double throughputMbps = (packetCount * packetSizeBytes * 8.0 / 1024)
                / (totalTimeSeconds / 1000); // Mbps
        System.out.println("吞吐量: " + throughputMbps + " Mbps");

        // 计算丢包率
        double lossRate = (double) (packetCount - receivedCount) / packetCount;
        System.out.println("丢包率: " + (lossRate * 100) + "%");
    }
}