package org.example;

import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MQTTThroughputTest {

    static String topic = "sensor/data";//订阅的话题
    static String content = "Test message";//发送消息内容
    static int qos = 0;//服务质量，0为最低
    static String broker = "tcp://10.32.61.65:1883";//目标服务器网址
    static String clientId = "JavaMQTTPublisher";//客户端ID
    static MemoryPersistence persistence = new MemoryPersistence();//持久化参数
    static int messageCount = 1000; // 发送消息的数量
    static long startTime;//消息发送开始时间
    static long endTime;//消息发送结束时间
    static int receivedCount = 0; // 接收到的消息数量
    static int messageSizeBytes = content.getBytes().length;//消息大小（以字节为单位）

    public static void main(String[] args) {

        try {
            //连接到MQTT服务端
            MqttClient client = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            System.out.println("连接到broker: " + broker);
            client.connect(connOpts);
            System.out.println("已连接");

            // 订阅消息
            client.subscribe(topic);
            System.out.println("订阅消息topic: " + topic);

            // 创建消息监听器
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    System.out.println("连接丢失");
                }

                @Override
                public void messageArrived(String topic, MqttMessage message){
                    receivedCount++;
                    //System.out.println("收到消息: " + new String(message.getPayload()));
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                }
            });

            //发送数据
            startTime = System.currentTimeMillis();
            for (int i = 0; i < messageCount; i++) {
                String message = content;
                MqttMessage mqttMessage = new MqttMessage(message.getBytes());
                mqttMessage.setQos(qos);
                client.publish(topic, mqttMessage);
            }
            endTime = System.currentTimeMillis();

            Thread.sleep(1000);

            System.out.println("发送消息数: " + messageCount);
            System.out.println("接收消息数: " + receivedCount);
            System.out.println("所需时间: " + (endTime - startTime) + " ms");
            System.out.println("吞吐量: " + (double)(messageCount * messageSizeBytes * 8 / 1024)
                    / ((double)(endTime - startTime) / 1000) + "Mbps");

            // 计算丢包率
            double lossRate = (double)(messageCount - receivedCount) / (double)messageCount;
            System.out.println("丢包率: " + lossRate + "%");

            client.disconnect();
            System.out.println("连接丢失");
        } catch (Exception me) {
            me.printStackTrace();
        }
    }
}
