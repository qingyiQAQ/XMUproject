#include <iostream>
#include <regex>
using namespace std;
int main() {
    string s;
    while (1) {
        cin >> s;
        if (s=="exit")break;
        regex pattern1("[a-zA-Z_][a-zA-Z0-9_]*");
        regex pattern2("[+-]?(\\d+\\.?\\d*|\\.\\d+)([eE][+-]?\\d+)?");
        if(regex_match(s, pattern1))
            cout << "���Ǳ�ʶ��" << s << endl;
        else if (regex_match(s, pattern2))
            cout << "����ʵ��" << s << endl;
        else cout << "ɶҲ����" << endl;
    }
    return 0;
}
