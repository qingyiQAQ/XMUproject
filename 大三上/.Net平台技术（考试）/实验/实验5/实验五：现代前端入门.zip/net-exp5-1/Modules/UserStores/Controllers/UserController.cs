﻿using Microsoft.AspNetCore.Mvc;

namespace UserStores.Controllers
{
    public class UserController : Controller
    {
        
    }
}
