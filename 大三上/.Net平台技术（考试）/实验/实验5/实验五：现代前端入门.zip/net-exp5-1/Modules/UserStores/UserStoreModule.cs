﻿global using NetCourse.Framework;
global using NetCourse.Framework.Security;

namespace UserStores
{
    public class UserStoreModule
    {
    }
}
