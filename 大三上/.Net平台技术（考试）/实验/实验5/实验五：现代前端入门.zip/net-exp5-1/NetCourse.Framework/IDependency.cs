﻿global using Microsoft.Extensions.DependencyInjection;
global using Ricebird.Framework;

namespace NetCourse.Framework
{
    public interface IDependency
    {
    }

    public interface IScopedDependency
    {

    }

    public interface ISingletonDependency
    {

    }
}