﻿namespace NetCourse.Framework
{
    public class HostEnv
    {
        public List<Type> AllEntities { get; set; } = new List<Type>();
    }
}
