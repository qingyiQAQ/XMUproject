﻿namespace XmuAuthen
{
    public class XmuAuthenModule
    {
    }
}
