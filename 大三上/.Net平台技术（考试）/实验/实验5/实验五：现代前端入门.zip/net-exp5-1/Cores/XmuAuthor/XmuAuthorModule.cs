﻿namespace XmuAuthor
{
    public class XmuAuthorModule
    {
    }
}
