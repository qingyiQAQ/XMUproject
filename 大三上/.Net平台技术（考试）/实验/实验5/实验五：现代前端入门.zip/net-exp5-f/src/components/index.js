import WordPage from './word-page.vue'
export default {
    install (app) {
        app.component("word-page", WordPage);
    }
}