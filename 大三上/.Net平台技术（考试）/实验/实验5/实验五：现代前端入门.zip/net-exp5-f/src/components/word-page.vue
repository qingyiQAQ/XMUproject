<template>
    <div class="page-wrapper">
        <div class="page-div">
            <slot>
            </slot>
        </div>
    </div>
</template>

<style lang="less">
@import "@/assets/paper.less";
</style>