﻿namespace UserStores
{
    public class UserStoreModule
    {
    }
}
