﻿global using Microsoft.Extensions.DependencyInjection;

namespace NetCourse.Framework
{
    public interface IDependency
    {
    }

    public interface IScopedDependency
    {

    }

    public interface ISingletonDependency
    {

    }
}