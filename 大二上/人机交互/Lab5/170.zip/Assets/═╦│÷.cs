using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class 退出 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public void 退出游戏()
    {
        UnityEngine.Application.Quit();
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
